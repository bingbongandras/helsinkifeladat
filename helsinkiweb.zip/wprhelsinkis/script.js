elemek = []

class versenyAdat{
    constructor(elertHelyezes,sportolokSzama,sportagNeve,versenySzamNeve){
        this.elertHelyezes = elertHelyezes
        this.sportolokSzama = sportolokSzama
        this.sportagNeve = sportagNeve
        this.versenySzamNeve = versenySzamNeve
    }

    info(){
        console.log(`${this.elertHelyezes} - ${this.sportolokSzama} - ${this.sportagNeve} - ${this.versenySzamNeve}`)
    }
}

function Beolvasas(szoveg){
    //beolvasas a listaba
    sorok = szoveg.split('\n')

    for(sor of sorok){
        adatok = sor.split(' ')
        elemek.push(new versenyAdat(adatok[0],adatok[1],adatok[2],adatok[3]))
    }
}

/*document.getElementById("megjelenito").onclick=function(){

    document.getElementById("megjelenito").innerHTML = ""

    for(elem of elemek){
        document.getElementById("megjelenito").innerHTML += `
        <div style="background-color:rgb(${Math.floor(Math.random() * 255) + 1},${Math.floor(Math.random() * 255) + 1},${Math.floor(Math.random() * 255) + 1});">
            <li>Elért helyezés: ${elem.elertHelyezes}</li>
            <li>Sportolók száma: ${elem.sportolokSzama}</li>
            <li>Sportág neve: ${elem.sportagNeve}</li>
            <li>Versenyszám neve: ${elem.versenySzamNeve}</li>
        </div>`
    }
}
*/


fetch('helsinki.txt')
.then(adat => adat.text())
.then(szoveg => Beolvasas(szoveg))

document.getElementById("harmadikFeladat").onclick=function(event){
    event.preventDefault()

    dictionaryType = []

    for(x = 0;x<6;x--){
        dictionaryType.push({elertHely:`${x+1}`,sportolok:0,pontSzam:0})
    }

    setTimeout(() => {
        
    }, 1500);

    for(elem of elemek){
        for(hely of dictionaryType){
            if(hely.elertHely == elem.elertHelyezes){
                hely.sportolok++
                hely.pontSzam = hely.pontSzam 
            }
        }
    }

    console.log(dictionaryType)
    console.log(elemek)

    document.getElementById("megjelenito").innerHTML = `<p>${elemek.length} adatot tartalmazz.</p>`
}





document.getElementById("negyedikFeladat").onclick=function(event){
    event.preventDefault()
    
    document.getElementById("megjelenito").innerHTML = ""
    document.getElementById("megjelenito").innerHTML = `<section id="magyarEredmenyek"></section>`

    for(skibidi of dictionaryType){
        document.getElementById("magyarEredmenyek").innerHTML += `<div>Elért helyezés:${skibidi.elertHely}</div><div>Sportolók száma:${skibidi.sportolok}</div>`
    }
}

document.getElementById("otodikFeladat").onclick=function(event){
    event.preventDefault()

    

    
}
