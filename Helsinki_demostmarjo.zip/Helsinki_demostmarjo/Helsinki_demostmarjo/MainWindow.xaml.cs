﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Helsinki_demostmarjo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void kilepes_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void programrol_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ez a program beolvassa a helsinki fájlt, amit a felhasználó el tud menteni máshova");
        }
        private void megnyitas_Click(object sender, RoutedEventArgs e)
        {
            HelsinkiTextBlock.Text = "";
            foreach (var line in File.ReadAllLines("helsinki.txt"))
            {
                HelsinkiTextBlock.Text += line + "\n";
            }
        }

        private void mentesdialog_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Hello World!", "This is the title of the MessageBox", MessageBox);
            //StreamWriter stream = new StreamWriter(HelsinkiTextBlock.Text);
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".text"; // Default file extension
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show save file dialog box
            bool? result = dlg.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                File.WriteAllText(dlg.FileName, HelsinkiTextBlock.Text);
            }
        }
    }
}
